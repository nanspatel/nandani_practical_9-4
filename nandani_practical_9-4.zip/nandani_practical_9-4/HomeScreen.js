import React from "react";
import {
  StyleSheet,
  Text,
  View,
  Image,
  TextInput,
  Button,
  TouchableOpacity,
  ImageBackground,
  StatusBar,
  AsyncStorage,
  Platform,
} from "react-native";
import * as ImagePicker from "expo-image-picker";

const { useState, useEffect } = React;

const HomeScreen = ({ navigation }) => {
  const [count, setCount] = useState(0);
  const [userRequest, setUserRequest] = useState({
    data: [],
    password: "",
    mbl_no: "",
    username: "",
    email: "",
    gender: "",
    profile_image: "",
  });
  const {
    loading,
    user,
    data,
    password,
    mbl,
    username,
    mbl_no,
    email,
    gender,
    profile_image,
  } = userRequest;

  function onregister() {
    data.push({ username, mbl_no, email, gender, profile_image });
    console.log(data);

    AsyncStorage.setItem("userdata", JSON.stringify(data));

    navigation.navigate("Profile");
  }
  useEffect(() => {
    (async () => {
      if (Platform.OS !== "web") {
        const {
          status,
        } = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (status !== "granted") {
          alert("Sorry, we need camera roll permissions to make this work!");
        }
      }
    })();
  }, []);
  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    console.log(result);

    if (!result.cancelled) {
      setUserRequest({ profile_image: result.uri });
    }
  };

  return (
    <ImageBackground
      style={styles.flex}
      source={{
        uri:
          "https://png.pngtree.com/thumb_back/fh260/back_pic/04/15/46/215822baed8722c.jpg",
      }}
    >
      <Text style={styles.reg}>REGISTER</Text>

      <View style={styles.container}>
        <StatusBar style="auto" />
        <View
          style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
        ></View>
        <View style={styles.inputView}>
          <TextInput
            style={styles.TextInput}
            placeholder="Name"
            placeholderTextColor="#0a4f5c"
            onChangeText={(name) => {
              setUserRequest({ username: name });
            }}
          />
        </View>
        <View style={styles.inputView}>
          <TextInput
            style={styles.TextInput}
            placeholder="Mobile Number"
            placeholderTextColor="#0a4f5c"
            keyboardType={"numeric"}
            onChangeText={(mbl) => {
              mbl_no: mbl;
            }}
          />
        </View>
        <View style={styles.inputView}>
          <TextInput
            style={styles.TextInput}
            placeholder="email"
            placeholderTextColor="#0a4f5c"
            onChangeText={(email) => {
              email: email;
            }}
          />
        </View>
        <View style={styles.inputView}>
          <TextInput
            style={styles.TextInput}
            placeholder="gender"
            placeholderTextColor="#0a4f5c"
            onChangeText={(gender) => {
              gender: gender;
            }}
          />
        </View>
        <TouchableOpacity
          style={{
            width: "90%",
            borderRadius: 25,
            height: 35,
            alignItems: "center",
            justifyContent: "center",
            margin: 0,
            backgroundColor: "#e2d495",
          }}
          onPress={pickImage}
        >
          <Text style={styles.imgtxt}>Pick image from camera roll</Text>
        </TouchableOpacity>

        {profile_image && (
          <Image
            source={{ uri: profile_image }}
            style={{ width: 200, height: 200, margin: 20 }}
          />
        )}

        <TouchableOpacity style={styles.regbtn} onPress={onregister}>
          <Text style={styles.imgtxt}>Register</Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
};
export default HomeScreen;
const styles = StyleSheet.create({
  flex: {
    flex: 1,
    resizeMode: "cover",
    justifyContent: "center",
  },
  container: {
    alignItems: "center",
    justifyContent: "center",
  },

  image: {
    marginBottom: 20,
  },

  inputView: {
    backgroundColor: "#e2d495",
    borderRadius: 30,
    width: "70%",
    height: 40,
    marginBottom: 15,
    alignItems: "center",
  },

  TextInput: {
    height: 50,
    flex: 1,
    padding: 10,
    marginLeft: 20,
  },

  forgot_button: {
    height: 30,
    marginBottom: 30,
  },

  regbtn: {
    width: "70%",
    borderRadius: 25,
    height: 40,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 20,
    backgroundColor: "#e2d495",
  },
  reg: {
    margin: 15,
    textAlign: "center",
    fontSize: 20,
    color: "#e2d495",
  },
  imgtxt: {
    fontSize: 15,
    color: "#0a4f5c",
  },
});
