import * as React from 'react';
import { Text, View } from 'react-native';

const ProfileScreen = ({ navigation, route }) => {
  return <Text>profile</Text>;
};
export default ProfileScreen;